(function () {
    'use strict';

    window.SHOPIFYNEPAL = {
      global: {},
      admin: {},
      homeslider: {},
      product: {},
      products : {},
      validation:{},
      order:{},
    };
})();
