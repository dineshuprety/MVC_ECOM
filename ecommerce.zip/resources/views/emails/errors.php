<!DOCTYPE html>
<html>
    <head>
        <title>Error</title>
        <style>
            body {
                width: 650px;
                font-family: work-Sans, sans-serif;
                background-color: #f6f7fb;
                display: block;
                margin: 0 auto;
                padding-top: 50px;
            }
            a {
                text-decoration: none;
            }
            span {
                font-size: 14px;
            }
            p {
                font-size: 13px;
                line-height: 1.7;
                letter-spacing: 0.7px;
                margin-top: 0;
            }
            .text-center {
                text-align: center;
            }
        </style>
    </head>
    <body>
        <table border="0" cellpadding="0" cellspacing="0" style="max-width: 650px;" width="100%">
            <tr>
                <td align="center" valign="top">
                    <table border="0" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-color: #e5e5e5; border-style: solid; border-width: 0 1px 1px 1px;" width="100%">
                        <tr>
                            <td align="center" valign="top" style="padding-bottom: 20px;">
                                <a href="#" target="_blank" style="text-decoration: none;">
                                    <img class="img-fluid" src="../../../public/images/error/error.png" alt="" border="0" style="display: block; width: 240px; height: auto; margin-top: 50px;" />
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td align="center" valign="top" style="padding-bottom: 5px; padding-left: 20px; padding-right: 20px;">
                                <h2
                                    style="
                                        color: #000000;
                                        font-family: 'Poppins', Helvetica, Arial, sans-serif;
                                        font-size: 28px;
                                        font-weight: 500;
                                        font-style: normal;
                                        letter-spacing: normal;
                                        line-height: 36px;
                                        text-transform: none;
                                        text-align: center;
                                        padding: 0;
                                        margin: 0;
                                    "
                                >
                                    Error Messages
                                </h2>
                            </td>
                        </tr>
                        <tr>
                            <td align="center" valign="top" style="padding-bottom: 30px; padding-left: 20px; padding-right: 20px;">
                                <h2
                                    class="text"
                                    style="
                                        color: #999999;
                                        font-family: 'Poppins', Helvetica, Arial, sans-serif;
                                        font-size: 16px;
                                        font-weight: 500;
                                        font-style: normal;
                                        letter-spacing: normal;
                                        line-height: 24px;
                                        text-transform: none;
                                        text-align: center;
                                        padding: 0;
                                        margin: 0;
                                    "
                                >
                                    <?php echo "Error: {$data}" ?>.
                                </h2>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </body>
</html>
