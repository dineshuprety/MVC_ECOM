 
<?php $__env->startSection('title', 'Homepage'); ?>
<?php $__env->startSection('data-page-id', 'home'); ?> 
<?php $__env->startSection('headerclass', 'home-2'); ?>
<?php $__env->startSection('content'); ?>

<!-- el root  -->
<div class="display-products" data-token="<?php echo e($token); ?>" id="root">
      <!-- Slider Arae Start -->
      <div class="slider-area">
         <div class="slider-active-3 owl-carousel slider-hm8 owl-dot-style">
            <?php if(count($slider)): ?> <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sliders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Slider Single Item Start -->
            <div class="slider-height-13 d-flex align-items-start justify-content-start bg-img" style="background-image:url(/<?php echo e(str_replace('\\','/',$sliders->image_path)); ?>">
               <div class="container">
                  <div class="slider-content-15 slider-content-13 slider-animated-1 text-left">
                     <h1 class="animated">
                        <strong><?php echo e($sliders['title']); ?></strong>
                     </h1>
                     <p class="animated"><?php echo e($sliders['description']); ?></p>
                     <a href="<?php echo e($sliders['url']); ?>" class="shop-btn animated">SHOP NOW</a>
                  </div>
               </div>
            </div>
            <!-- Slider Single Item End --> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php else: ?>
            <!-- Slider Single Item Start -->
            <div class="slider-height-13 d-flex align-items-start justify-content-start bg-img" style="background-image: url('https://estore.dineshuprety.com.np/ecom/assets/images/slider-image/sample-29.jpg');">
               <div class="container">
                  <div class="slider-content-15 slider-content-13 slider-animated-1 text-left">
                     <h1 class="animated"> Interior Design Furniture <br />
                        <strong>For Your Dream Room</strong>
                     </h1>
                     <p class="animated">Kiln-dried hardwood frame. Apartment friendly design Sinuous Spring suspension system</p>
                     <a href="/" class="shop-btn animated">SHOP NOW</a>
                  </div>
               </div>
            </div>
            <!-- Slider Single Item End --> <?php endif; ?>
         </div>
      </div>
   <!-- Slider Arae End -->
   <!-- Banner Area Start -->
      <div class="banner-3-area mt-30px">
         <div class="container">
            <div class="row">
               <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 mb-res-xs-30 mb-res-sm-30">
                  <div class="banner-wrapper banner-box">
                     <a href="shop-4-column.html">
                     <img src="https://estore.dineshuprety.com.np/ecom/assets/images/banner-image/40.jpg" alt="" />
                     </a>
                  </div>
               </div>
               <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 mb-res-xs-30 mb-res-sm-30">
                  <div class="banner-wrapper banner-box">
                     <a href="shop-4-column.html">
                     <img src="https://estore.dineshuprety.com.np/ecom/assets/images/banner-image/41.jpg" alt="" />
                     </a>
                  </div>
               </div>
               <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                  <div class="banner-wrapper banner-box">
                     <a href="shop-4-column.html">
                     <img src="https://estore.dineshuprety.com.np/ecom/assets/images/banner-image/42.jpg" alt="" />
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
   <!-- Banner Area End -->

   <!-- Feature Tab Area Start -->
      <section class="category-tab-area mt-100px mb-70px">
         <div class="container">
         <div class="row">
            <div class="col-md-12 text-center">
               <!-- Section Title -->
               <div class="section-title underline-shape underline-shape-bottom">
                  <h2>Feature Products</h2>
                  <p>Feature products to weekly line up</p>
               </div>
               <!-- Section Title -->
            </div>
         </div>
         <!-- Tab panes -->
         <div class="tab-content">
            <!-- 1st tab start -->
            <div class="tab-pane active">
               <!-- Best Sell Slider Carousel Start -->
               <div class="best-sell-slider owl-carousel owl-nav-style-3">
                  <!-- Product Single Item --> <?php if(count($featureproducts)): ?> <?php $__currentLoopData = $featureproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featureproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <div class="product-inner-item">
                     <article class="list-product mb-30px">
                        <div class="img-block">
                           <a href="/product/<?php echo e($featureproduct['id']); ?>" class="thumbnail">
                           <img class="first-img" src="/<?php echo e($featureproduct['product_image_path']); ?>" alt="<?php echo e($featureproduct['title']); ?>" />
                           <img class="second-img" src="/<?php echo e($featureproduct['hover_image_path']); ?>" alt="<?php echo e($featureproduct['title']); ?>" />
                           </a>
                           <div class="add-to-link">
                              <ul>
                                 <li>
                                    <a @click="productView(<?php echo e($featureproduct['id']); ?>)" data-toggle="modal" data-target="#exampleModal" title="Add to Cart">
                                    <i class="ion-bag"></i>
                                    </a>
                                 </li>
                                 <!-- <li><a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i class="ion-ios-search-strong"></i></a></li> -->
                              </ul>
                           </div>
                        </div>
                        <ul class="product-flag">
                           <li class="new">Feature</li>
                        </ul>
                        <div class="product-decs text-center">
                           <a class="inner-link" href="/product/<?php echo e($featureproduct['id']); ?>">
                           <span>Shopify Nepal</span>
                           </a>
                           <h2>
                              <a href="/product/<?php echo e($featureproduct['id']); ?>" class="product-link"><?php echo e(substr($featureproduct['title'], 0, 18)); ?>..</a>
                           </h2>
                           <!-- <div class="rating-product"><i class="ion-android-star"></i><i class="ion-android-star"></i><i class="ion-android-star"></i><i class="ion-android-star"></i><i class="ion-android-star"></i></div> -->
                           <div class="pricing-meta">
                              <ul>
                                 <li class="old-price not-cut">रु <?php echo e($featureproduct['price']); ?></li>
                              </ul>
                           </div>
                        </div>
                     </article>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php else: ?> 
                  <p> NO DATA FOUND</p>
                  <?php endif; ?>
                  <!-- Best Sell Slider Carousel End -->
               </div>
            </div>
         </div>
      </section>
   <!-- Feature Tab Area end -->
   <!-- Static Countdown Area Start -->
      <section class="static-countdown-area" style="background-image: url('https://estore.dineshuprety.com.np/ecom/assets/images/section-bg/static-countdown-bg.jpg')">
         <div class="container">
            <div class="row">
               <div class="col-md-5 d-flex align-self-center">
                  <div class="static-countdown-content">
                     <h2>HOT DEALS PRODUCTS</h2>
                     <p class="countdown-price">रु 100 - रु 2k</p>
                     <p>Available in Shopifynepal </p>
                     <div class="clockdiv">
                        <div data-countdown="2021/11/01"></div>
                     </div>
                     <a class="shop_now" href="/hotsales">Shop Now</a>
                  </div>
               </div>
            </div>
         </div>
      </section>
   <!-- Static Countdown Area End -->
   <!-- hotdeal Tab Area Start -->
      <section class="category-tab-area mt-100px mb-70px">
         <div class="container">
         <div class="row">
            <div class="col-md-12 text-center">
               <!-- Section Title -->
               <div class="section-title underline-shape underline-shape-bottom">
                  <h2>Hot Deals Products</h2>
                  <p>Hot deals products to weekly line up</p>
               </div>
               <!-- Section Title -->
            </div>
         </div>
         <!-- Tab panes -->
         <div class="tab-content">
            <!-- 1st tab start -->
            <div class="tab-pane active">
               <!-- Best Sell Slider Carousel Start -->
               <div class="best-sell-slider owl-carousel owl-nav-style-3">
                  <?php if(count($hotproducts)): ?>
                  <!-- Product Single Item --> <?php $__currentLoopData = $hotproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <div class="product-inner-item">
                     <article class="list-product mb-30px">
                        <div class="img-block">
                           <a href="/product/<?php echo e($hotproduct['id']); ?>" class="thumbnail">
                           <img class="first-img" src="/<?php echo e($hotproduct['product_image_path']); ?>" alt="<?php echo e($hotproduct['title']); ?>" />
                           <img class="second-img" src="/<?php echo e($hotproduct['hover_image_path']); ?>" alt="<?php echo e($hotproduct['title']); ?>" />
                           </a>
                           <div class="add-to-link">
                              <ul>
                                 <li>
                                    <a @click="productView(<?php echo e($hotproduct['id']); ?>)" data-toggle="modal" data-target="#exampleModal" title="Add to Cart">
                                    <i class="ion-bag"></i>
                                    </a>
                                 </li>
                                 <!-- <li><a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i class="ion-ios-search-strong"></i></a></li> -->
                              </ul>
                           </div>
                        </div>
                        <ul class="product-flag">
                           <li class="new">Sales</li>
                        </ul>
                        <div class="product-decs text-center">
                           <a class="inner-link" href="/product/<?php echo e($hotproduct['id']); ?>">
                           <span>Shopify Nepal</span>
                           </a>
                           <h2>
                              <a href="/product/<?php echo e($hotproduct['id']); ?>" class="product-link"><?php echo e(substr($hotproduct['title'], 0, 18)); ?>..</a>
                           </h2>
                           <!-- <div class="rating-product"><i class="ion-android-star"></i><i class="ion-android-star"></i><i class="ion-android-star"></i><i class="ion-android-star"></i><i class="ion-android-star"></i></div> -->
                           <div class="pricing-meta">
                              <?php if($hotproduct['product_on'] == 1): ?> 
                              <ul>
                                 <li class="old-price">रु <?php echo e($hotproduct['price']); ?></li>
                                 <li class="current-price">रु <?php echo e($hotproduct['sales_price']); ?></li>
                                 <?php 
                                 $discount_per = (($hotproduct['price'] - $hotproduct['sales_price']) * 100) / $hotproduct['price'];
                                  ?>
                                 <li class="discount-price">-<?php echo e($discount_per); ?>%</li>
                              </ul>
                              <?php endif; ?> 
                           </div>
                        </div>
                     </article>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php else: ?> 
                  <p> NO DATA FOUND</p>
                  <?php endif; ?>
               </div>
            </div>
         </div>
      </section>
   <!-- hot deal Tab Area end -->
   
   <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

   <section class="category-tab-area mt-100px mb-70px">
      <div class="container">
         <div class="row">
            <div class="col-md-12 text-center">
               <!-- Section Title -->
               <div class="section-title underline-shape underline-shape-bottom">
                  <h2>Products</h2>
                  <p> All products to weekly line up</p>
               </div>
               <!-- Section Title -->
            </div>
         </div>
         <!-- Tab panes -->
         <div class="row">
            <div class="col-xl-3 col-md-4 col-sm-6" v-cloak v-for="product in products">
               <article class="list-product mb-30px">
                  <div class="img-block">
                     <a :href="'/product/'+ product.id" class="thumbnail">
                     <img class="first-img" :src="'/' + product.product_image_path" alt="" />
                     <img class="second-img" :src="'/' + product.hover_image_path" alt="" />
                     </a>
                     <div class="add-to-link">
                        <ul>
                           <li>
                              <a @click="productView(product.id)" data-toggle="modal" data-target="#exampleModal" title="Add to Cart">
                              <i class="ion-bag"></i>
                              </a>
                           </li>
                           <!-- <li><a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i class="ion-ios-search-strong"></i></a></li> -->
                        </ul>
                     </div>
                  </div>
                  <ul class="product-flag">
                     <li class="new"  v-if='product.product_on == 1'>hot deals</li>
                     <li class="new"  v-else-if='product.product_on == 2'>feature</li>
                     <li class="new"  v-else>new</li>
                  </ul>
                  <div class="product-decs text-center">
                     <a class="inner-link" :href="'/product/'+ product.id">
                     <span>Shopify Nepal</span>
                     </a>
                     <h2>
                        <a :href="'/product/'+ product.id" class="product-link">{{ stringLimit(product.title, 18) }}</a>
                     </h2>
                     <!-- <div class="rating-product"><i class="ion-android-star"></i><i class="ion-android-star"></i><i class="ion-android-star"></i><i class="ion-android-star"></i><i class="ion-android-star"></i></div> -->
                     <div class="pricing-meta">
                        <ul v-if="product.product_on == 1">
                           <li class="old-price">रु {{product.price}}</li>
                           <li class="current-price">रु {{product.sales_price}}</li>
                           <li class="discount-price">-{{ discountedPrice(product) }}%</li>
                        </ul>
                        <ul v-else>
                           <li class="old-price not-cut">रु {{product.price}}</li>
                        </ul>
                     </div>
                  </div>
               </article>
            </div>
            <div class="center">
               <img v-show="loading" src="/images/icons/frontloading.gif" alt="frontloading.gif" width="60px">
            </div>
         </div>
   </section>
   <?php echo $__env->make('includes.product_model', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<!-- end -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>