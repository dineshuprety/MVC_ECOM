 
<?php $__env->startSection('title'); ?><?php echo e(user()->username); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('data-page-id', 'user'); ?> 
<?php $__env->startSection('content'); ?> 
<div class="home">
   <section class="display-products" data-token=<?php echo e($token); ?>>
      <!-- Breadcrumb Area start -->
      <section class="breadcrumb-area"  v-cloak>
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="breadcrumb-content">
                     <h1 class="breadcrumb-hrading">User Dashboard</h1>
                     <ul class="breadcrumb-links">
                        <li>
                           <a href="/">Home</a>
                        </li>
                        <li><?php echo e(user()->username); ?></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Breadcrumb Area End -->
      <!-- account area start -->
      <div class="checkout-area mtb-60px">
         <div class="container">
            <div class="row">
               <div class="ml-auto mr-auto col-lg-9">
                  <div class="checkout-wrapper">
                     <div id="faq" class="panel-group">
                       <!-- include information page -->
                       <?php echo $__env->make('user.changeuserinformation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <!-- end information -->

                        <!-- include change password  -->
                        <?php echo $__env->make('user.chnagepassword', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <!-- end password -->

                         <!-- include order details  -->
                         <?php echo $__env->make('user.orderinformation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <!-- end order details -->
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- account area end -->
   </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>