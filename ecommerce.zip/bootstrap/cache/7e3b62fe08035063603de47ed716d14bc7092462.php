<?php $__env->startSection('title','order track'); ?> 
<?php $__env->startSection('data-page-id', 'trackOrder'); ?>
<?php $__env->startSection('headerclass', ''); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Area start -->
<div class="display-products">
   <section class="breadcrumb-area">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <div class="breadcrumb-content">
                  <h1 class="breadcrumb-hrading">Order Track Page</h1>
                  <ul class="breadcrumb-links">
                     <li><a href="/">Home</a></li>
                     <li>Track Order</li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!-- Breadcrumb Area End -->
   <div class="shop-category-area">
      <div class="container">
         <article class="card">
            <header class="card-header"> <b> My Orders / Tracking </b> </header>
            <div class="card-body">
               <div class="row" style="margin-left: 30px; margin-top: 20px;">
                  <div class="col-md-2">
                     <b> Invoice Number </b><br>
                     <?php echo e($track->invoice_no); ?>

                  </div>
                  <!-- // end col md 2 -->
                  <div class="col-md-2">
                     <b> Order Date </b><br>
                     <?php echo e($track->order_date); ?>

                  </div>
                  <!-- // end col md 2 -->
                  <div class="col-md-2">
                     <b> Shipping By - <?php echo e($track->name); ?> </b><br>
                     <?php echo e($track->address); ?> / <?php echo e($track->city); ?>

                  </div>
                  <!-- // end col md 2 -->
                  <div class="col-md-2">
                     <b> User Mobile Number </b><br>
                     <?php echo e($track->phone); ?>

                  </div>
                  <!-- // end col md 2 -->
                  <div class="col-md-2">
                     <b> Payment Method  </b><br>
                     <?php echo e($track->payment_method); ?>

                  </div>
                  <!-- // end col md 2 -->
                  <div class="col-md-2">
                     <b> Total Amount  </b><br>
                     Rs <?php echo e($track->amount); ?>

                  </div>
                  <!-- // end col md 2 -->
               </div>
               <!-- // end row   -->     
               <div class="track">
                  <?php if($track->status == 'pending'): ?>
                  <div class="step "> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Pending</span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text"> Order Confirmed</span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text"> Order Processing  </span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Picked</span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Shipped </span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Delivered </span> </div>
                  <?php elseif($track->status == 'confirm'): ?>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Pending</span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text"> Order Confirmed</span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text"> Order Processing  </span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Picked</span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Shipped </span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Delivered </span> </div>
                  <?php elseif($track->status == 'processing'): ?>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Pending</span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text"> Order Confirmed</span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text"> Order Processing  </span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Picked</span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Shipped </span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Delivered </span> </div>
                  <?php elseif($track->status == 'picked'): ?>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Pending</span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text"> Order Confirmed</span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text"> Order Processing  </span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Picked</span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Shipped </span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Delivered </span> </div>
                  <?php elseif($track->status == 'shipped'): ?>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Pending</span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text"> Order Confirmed</span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text"> Order Processing  </span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Picked</span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Shipped </span> </div>
                  <div class="step"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Delivered </span> </div>
                  <?php elseif($track->status == 'delivered'): ?>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Pending</span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text"> Order Confirmed</span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text"> Order Processing  </span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Picked</span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Order Shipped </span> </div>
                  <div class="step active"> <span class="icon"> <i class="ionicons ion-checkmark"></i> </span> <span class="text">Delivered </span> </div>
                  <?php endif; ?>  
               </div>
               <!-- // end track  -->
               <hr>
               <br><br>
            </div>
         </article>
      </div>
   </div>
</div><br>
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Shop Category Area End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>