<footer class="footer">
        © 2021 40plus Template with <i class="mdi mdi-heart text-danger"></i> by Dinesh.
    </footer>