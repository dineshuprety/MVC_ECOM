<div class="panel panel-default single-my-account">
   <div class="panel-heading my-account-title">
      <h3 class="panel-title"><span>3 .</span> <a data-toggle="collapse" data-parent="#faq" href="#my-account-3"> your Order information </a></h3>
   </div>
   <div id="my-account-3" class="panel-collapse collapse show">
      <div class="panel-body">
         <div class="myaccount-info-wrapper">
            <div class="account-info-wrapper">
               <h4>My Order Information</h4>
               <h5>Your Order Details</h5>
            </div>
            <table id="myorder" class="table table-striped table-bordered" cellspacing="0" width="100%" data-form="deleteForm">
               <thead>
                  <tr>
                        <th>Name </th>
                        <th>Date </th>
                        <th>Invoice </th>
                        <th>Amount </th>
                        <th>Payment </th>
                        <th>Status </th>
                        <th>Action </th>
                  </tr>
               </thead>
               <tbody>
                  <tr>
                     
                  </tr>
               </tbody>
            </table>
         </div>
      </div>
   </div>
</div>
