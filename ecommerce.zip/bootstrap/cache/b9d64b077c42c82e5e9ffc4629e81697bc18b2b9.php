<div class="mobile-menu-area">
                            <div class="mobile-menu">
                                <nav id="mobile-menu-active">
                                    <ul class="menu-overflow">
                                        <li>
                                            <a href="/">HOME</a>
                                            
                                        </li>
                                        <li>
                                            <a href="/products">Shop</a>
                                           
                                        </li>
                                        <li>
                                            <a href="/about">About Me</a>
                                            
                                        </li>
                                        <li><a href="/contact">Contact Us</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>