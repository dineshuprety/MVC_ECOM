 <?php $__env->startSection('title', 'Contact Details'); ?> <?php $__env->startSection('data-page-id', 'contactTable'); ?> <?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php echo $__env->make('includes.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-xl-12">
            <div class="card m-b-30">
                <div class="card-body">
                    <div class="table-responsive">
                        <h4 class="mt-0 header-title">Contacts Tables</h4>
                        <?php if(count($contacts)): ?>
                        <table class="table table-striped table-bordered" cellspacing="0" width="100%" data-form="deleteForm">
                            <thead>
                                <tr class="titles">
                                    <!-- <th>Id</th> -->
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Subject</th>
                                    <th>Message</th>
                                    <th>Created</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="c-table__cell"><?php echo e($contact['username']); ?></td>
                                    <td class="c-table__cell"><?php echo e($contact['email']); ?></td>
                                    <td class="c-table__cell"><?php echo e($contact['subject']); ?></td>
                                    <td class="c-table__cell"><?php echo e($contact['message']); ?></td>
                                    <td class="c-table__cell"><?php echo e($contact['added']); ?></td>
                                    <td class="c-table__cell">
                                        <!-- deleted size button -->
                                        <div data-toggle="tooltip" data-placement="top" title="Delete size" style="display: inline-block;">
                                            <form method="POST" action="/admin/contact/<?php echo e($contact['id']); ?>/delete" class="delete-item">
                                                <input type="hidden" name="token" value="<?php echo e(\App\Classes\CSRFToken::_token()); ?>" />
                                                <button type="submit" class="btn-sm btn-danger delete">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- table end -->
                        <!-- pagination start -->
                        <hr />
                        <ul class="pagination justify-content-end">
                            <?php echo $links; ?>

                        </ul>
                        <?php else: ?>
                        <p>You have not created any size</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page content Wrapper -->
    </div>
    <!-- container -->
</div>
<?php echo $__env->make('includes.delete-model', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>