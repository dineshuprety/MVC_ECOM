 <?php $__env->startSection('title', 'Retailer Users'); ?> <?php $__env->startSection('data-page-id', 'users'); ?> <?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php echo $__env->make('includes.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-xl-12">
            <div class="card m-b-30">
                <div class="card-body">
                    <div class="table-responsive">
                        <h4 class="mt-0 header-title">Retailer Users Table</h4>
                        <?php if(count($retailerUsers)): ?>
                        <table class="table table-hover" data-form="deletedProduct">
                            <thead>
                                <tr class="titles">
                                    <th>Full Name</th>
                                    <th>Phone Number</th>
                                    <th>Email</th>
                                    <th>Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $retailerUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="c-table__cell"><?php echo e($user['fullname']); ?></td>
                                    <td class="c-table__cell"><?php echo e($user['phone_number']); ?></td>
                                    <td class="c-table__cell"><?php echo e($user['email']); ?></td>
                                    <td class="c-table__cell"><?php echo e($user['added']); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- table end -->
                        <!-- pagination start -->
                        <hr />
                        <ul class="pagination justify-content-end">
                            <?php echo $links; ?>

                        </ul>
                        <?php else: ?>
                        <p>You do not have any users</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page content Wrapper -->
    </div>
    <!-- container -->
    <?php echo $__env->make('includes.delete-model', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <?php $__env->stopSection(); ?>
</div>

<?php echo $__env->make('admin.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>