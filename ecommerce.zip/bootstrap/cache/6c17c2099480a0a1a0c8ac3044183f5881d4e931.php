 <?php $__env->startSection('title', 'Wholesaler Users'); ?> <?php $__env->startSection('data-page-id', 'wholesalerusers'); ?> <?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php echo $__env->make('includes.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-xl-12">
            <div class="card m-b-30">
                <div class="card-body">
                    <div class="table-responsive">
                        <h4 class="mt-0 header-title">Wholesaler Users Table</h4>
                        <?php if(count($WholesaleUsers)): ?>
                        <table class="table table-hover" data-form="deleteForm">
                            <thead>
                                <tr class="titles">
                                    <th>Full Name</th>
                                    <th>Phone Number</th>
                                    <th>Email</th>
                                    <th>Pan Number</th>
                                    <th>Status</th>
                                    <th>Created At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $WholesaleUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="c-table__cell">
                                        <div class="user-wrapper">
                                            <div class="img-user">
                                                <img src="/<?php echo e($user['pan_image']); ?>" width="50" height="50" alt="user" class="rounded-circle" />
                                            </div>
                                            <div class="text-user">
                                                <h6><?php echo e($user['fullname']); ?></h6>
                                                <p><?php echo e($user['username']); ?></p>
                                            </div>
                                        </div>
                                        <div id="image-viewer">
                                            <span class="close">&times;</span>
                                            <img class="modal-content" id="full-image" />
                                        </div>
                                    </td>
                                    <td class="c-table__cell"><?php echo e($user['phone_number']); ?></td>
                                    <td class="c-table__cell"><?php echo e($user['email']); ?></td>
                                    <td class="c-table__cell"><?php echo e($user['pan_number']); ?></td>
                                    <?php if($user['status'] == 0): ?>
                                    <td class="c-table__cell">
                                        <span class="badge badge-warning"> Pending </span>
                                    </td>
                                    <?php else: ?>
                                    <td class="c-table__cell">
                                        <span class="badge badge-info"> Aproved </span>
                                    </td>
                                    <?php endif; ?>
                                    <td class="c-table__cell"><?php echo e($user['added']); ?></td>
                                    <td class="c-table__cell">
                                        <?php if($user['status'] == 0): ?>
                                        <span data-toggle="tooltip" data-placement="top" title="Aprove the user" style="display: inline-block;">
                                            <a href="/admin/users/wholesalers/<?php echo e($user['id']); ?>/updateStatus">
                                                <button type="button" class="btn-sm btn-success">
                                                    <i class="fa fa-arrow-up"></i>
                                                </button>
                                            </a>
                                        </span>
                                        <?php endif; ?>
                                        <!-- deleted -->
                                        <span data-toggle="tooltip" data-placement="top" title="Delete User" style="display: inline-block;" >
                                            <form method="POST" action="/admin/users/wholesalers/<?php echo e($user['id']); ?>/delete" class="delete-item">
                                                <input type="hidden" name="token" value="<?php echo e(\App\Classes\CSRFToken::_token()); ?>" />
                                                <button type="submit" class="btn-sm btn-danger delete" data-toggle="modal" data-target="#exampleModal">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- table end -->
                        <!-- pagination start -->
                        <hr />
                        <ul class="pagination justify-content-end">
                            <?php echo $links; ?>

                        </ul>
                        <?php else: ?>
                        <p>You do not have any Wholesaler users</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page content Wrapper -->
    </div>
    <!-- container -->

    <?php echo $__env->make('includes.delete-model', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>