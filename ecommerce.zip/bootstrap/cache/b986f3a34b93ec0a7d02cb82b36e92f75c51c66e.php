<!-- deleted model -->
<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" id="confirm" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
    <div class="modal-body">
        <p>Do you really want to delete item?</p>
      </div>
      <div class="modal-footer">
        <button type="button" id="deleted-btn" class="btn btn-danger">Delete</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>
<!-- deleted modal end -->

<!-- cancel model -->
<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" id="confirmcancel" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
    <div class="modal-body">
        <p>Do you really want to cancel item?</p>
      </div>
      <div class="modal-footer">
        <button type="button" id="cancel-btn" class="btn btn-danger">Yes</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
      </div>
    </div>
  </div>
</div>
<!-- cancel modal end -->